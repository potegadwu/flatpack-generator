document.addEventListener('DOMContentLoaded', () => {
    
    // Form elements
    const contactForm = document.getElementById('contact-form');
    const formSuccess = document.getElementById('form-success');
    const zipInput = document.getElementById('client-zip');
    const zipSuggestions = document.getElementById('zip-suggestions');
    const zipValidationMsg = document.getElementById('zip-validation-msg');
    const phoneInput = document.getElementById('client-phone');
    const phoneValidationMsg = document.getElementById('phone-validation-msg');
    
    // UK Postcode & Phone Validation State
    let isZipValid = true;
    let isPhoneValid = true;
    let debounceTimeout = null;

    // London Postcode Prefixes (Both Inner & Outer London areas to be fully comprehensive)
    const londonPrefixes = [
        'E', 'EC', 'N', 'NW', 'SE', 'SW', 'W', 'WC', // Inner London
        'BR', 'CR', 'DA', 'EN', 'HA', 'IG', 'KT', 'RM', 'SM', 'TW', 'UB', 'WD' // Outer London / Greater London
    ];

    // Helper: Classify valid UK postcode area
    function classifyPostcodeArea(postcode) {
        const formatted = postcode.trim().toUpperCase().replace(/\s+/g, '');
        
        // Belfast BT
        if (formatted.startsWith('BT')) {
            return { area: 'Belfast', supported: true, label: '✓ Belfast Area' };
        }
        
        // London: Starts with any of the London prefixes followed by a digit
        for (const prefix of londonPrefixes) {
            const regex = new RegExp('^' + prefix + '\\d', 'i');
            if (regex.test(formatted)) {
                return { area: 'London', supported: true, label: '✓ London Area' };
            }
        }
        
        // Other UK areas
        return { area: 'UK Standard', supported: false, label: '⚠️ UK Standard Area (Outside Belfast/London)' };
    }

    // Function: Update Postcode UI based on validity (completely local, non-blocking)
    function updatePostcodeUI(postcodeStr) {
        zipValidationMsg.innerHTML = '';
        zipInput.classList.remove('zip-input-error');
        isZipValid = true;
    }

    // Function: Trigger local postcode classification without external API validation
    function validatePostcodeAPI(postcode) {
        updatePostcodeUI(postcode);
    }

    // Function: Validate Phone Number (completely non-blocking, no UI messages)
    function validatePhoneNumber(phoneStr) {
        phoneValidationMsg.innerHTML = '';
        phoneInput.classList.remove('phone-input-error');
        isPhoneValid = true;
    }

    // Autocomplete Lookup
    if (zipInput && zipSuggestions) {
        zipInput.addEventListener('input', (e) => {
            const query = e.target.value.trim();
            
            // Clear previous debounce
            clearTimeout(debounceTimeout);
            
            if (query.length < 2) {
                zipSuggestions.classList.add('hidden');
                zipSuggestions.innerHTML = '';
                return;
            }

            // Debounce fetch request
            debounceTimeout = setTimeout(() => {
                fetch(`https://api.postcodes.io/postcodes/${encodeURIComponent(query)}/autocomplete`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 200 && data.result) {
                            const suggestions = data.result.slice(0, 5); // Limit to top 5 suggestions
                            
                            if (suggestions.length > 0) {
                                zipSuggestions.innerHTML = suggestions.map(item => `
                                    <div class="zip-suggestion-item">${item}</div>
                                `).join('');
                                zipSuggestions.classList.remove('hidden');
                            } else {
                                zipSuggestions.classList.add('hidden');
                            }
                        }
                    })
                    .catch(err => console.error('Error fetching suggestions:', err));
            }, 250);
        });

        // Autocomplete Suggestion Selection
        zipSuggestions.addEventListener('click', (e) => {
            if (e.target.classList.contains('zip-suggestion-item')) {
                zipInput.value = e.target.textContent;
                zipSuggestions.classList.add('hidden');
                zipSuggestions.innerHTML = '';
                validatePostcodeAPI(zipInput.value);
            }
        });

        // Validate on blur
        zipInput.addEventListener('blur', () => {
            // Slight delay to allow suggestion click to complete first
            setTimeout(() => {
                zipSuggestions.classList.add('hidden');
                validatePostcodeAPI(zipInput.value);
            }, 200);
        });
    }

    // Close suggestions if clicked outside
    document.addEventListener('click', (e) => {
        if (zipSuggestions && !zipInput.contains(e.target) && !zipSuggestions.contains(e.target)) {
            zipSuggestions.classList.add('hidden');
        }
    });

    // Phone Input Validation Event Listeners
    if (phoneInput) {
        phoneInput.addEventListener('input', (e) => {
            validatePhoneNumber(e.target.value);
        });

        phoneInput.addEventListener('blur', (e) => {
            validatePhoneNumber(e.target.value);
        });
    }
    
    // Form submission handling
    if (contactForm && formSuccess) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Validate fields before submitting
            validatePostcodeAPI(zipInput.value);
            validatePhoneNumber(phoneInput.value);
            
            // Gather input values to double check all required fields are filled out
            const clientNameVal = document.getElementById('client-name').value.trim();
            const clientZipVal = zipInput.value.trim();
            const clientEmailVal = document.getElementById('client-email').value.trim();
            const clientPhoneVal = phoneInput.value.trim();
            const clientMessageVal = document.getElementById('client-message').value.trim();

            if (!clientNameVal || !clientZipVal || !clientEmailVal || !clientPhoneVal || !clientMessageVal) {
                alert('Please fill out all required fields: Name, Postcode, Email, Phone Number, and Details.');
                return;
            }

            // Double check postcode validity (always true due to non-blocking validation)
            if (!isZipValid) {
                zipInput.focus();
                zipInput.classList.add('zip-input-error');
                return;
            }

            if (!isPhoneValid) {
                phoneInput.focus();
                phoneInput.classList.add('phone-input-error');
                return;
            }
            
            // Gather form values (note: description 'message' field is fully unrestricted with no character limits or validation caps)
            const formData = {
                name: clientNameVal,
                zip: clientZipVal,
                email: clientEmailVal,
                phone: clientPhoneVal,
                message: clientMessageVal,
                attachments: uploadedFiles.map(f => f.name)
            };
            
            console.log('Quote request sent successfully:', formData);
            
            // Clear files state
            uploadedFiles = [];
            renderFiles();
            
            // Toggle form visibility to show success box
            contactForm.classList.add('hidden');
            formSuccess.classList.remove('hidden');
            
            // Scroll to the form box smoothly so the success state is centered
            const formBox = document.getElementById('booking-form-box');
            if (formBox) {
                formBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });
    }
    
    // Smooth scrolling for anchor tags
    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            const targetId = link.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                e.preventDefault();
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Drag & Drop File Upload Logic
    const fileDropArea = document.getElementById('file-drop-area');
    const fileInput = document.getElementById('file-input');
    const fileList = document.getElementById('file-list');
    let uploadedFiles = []; // Store File objects

    // Expose renderFiles to form submit block
    function renderFiles() {
        if (!fileList) return;
        if (uploadedFiles.length === 0) {
            fileList.innerHTML = '';
            return;
        }

        fileList.innerHTML = uploadedFiles.map((file, idx) => `
            <div class="file-item" data-index="${idx}">
                <span class="file-icon">${file.name.endsWith('.pdf') ? '📄' : '🖼️'}</span>
                <span class="file-name" title="${file.name}">${file.name}</span>
                <span class="file-size">(${(file.size / 1024 / 1024).toFixed(2)} MB)</span>
                <button type="button" class="file-remove" data-index="${idx}">✕</button>
            </div>
        `).join('');

        // Add click events to remove buttons
        const removeButtons = fileList.querySelectorAll('.file-remove');
        removeButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const index = parseInt(btn.getAttribute('data-index'));
                uploadedFiles.splice(index, 1);
                renderFiles();
            });
        });
    }

    if (fileDropArea && fileInput && fileList) {
        // Highlight drop area when item is dragged over it
        ['dragenter', 'dragover'].forEach(eventName => {
            fileDropArea.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                fileDropArea.classList.add('highlight');
            }, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            fileDropArea.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                fileDropArea.classList.remove('highlight');
            }, false);
        });

        // Handle dropped files
        fileDropArea.addEventListener('drop', (e) => {
            const dt = e.dataTransfer;
            const files = dt.files;
            handleFiles(files);
        }, false);

        // Click on drop area to browse
        fileDropArea.addEventListener('click', () => {
            fileInput.click();
        });

        // Handle file picker selection
        fileInput.addEventListener('change', (e) => {
            handleFiles(e.target.files);
        });

        function handleFiles(files) {
            const maxFiles = 5;
            const maxSize = 10 * 1024 * 1024; // 10MB

            Array.from(files).forEach(file => {
                // Check if file is already added
                if (uploadedFiles.some(f => f.name === file.name && f.size === file.size)) {
                    return;
                }

                // Check limit
                if (uploadedFiles.length >= maxFiles) {
                    alert('You can upload a maximum of 5 files.');
                    return;
                }

                // Check size
                if (file.size > maxSize) {
                    alert(`File "${file.name}" is too large. Max size is 10MB.`);
                    return;
                }

                // Check format
                const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg', 'application/pdf'];
                const fileExt = file.name.slice(file.name.lastIndexOf('.')).toLowerCase();
                const isAllowedExt = ['.png', '.jpg', '.jpeg', '.pdf'].includes(fileExt);
                if (!allowedTypes.includes(file.type) && !isAllowedExt) {
                    alert(`Format of "${file.name}" is not supported. Please upload PNG, JPG, or PDF.`);
                    return;
                }

                uploadedFiles.push(file);
                renderFiles();
            });
        }
    }

    // Testimonials Carousel Logic
    const track = document.getElementById('carousel-track');
    const prevBtn = document.getElementById('carousel-prev');
    const nextBtn = document.getElementById('carousel-next');
    const dotsContainer = document.getElementById('carousel-dots');
    
    if (track && prevBtn && nextBtn) {
        const cards = Array.from(track.children);
        let currentIndex = 0;

        function getVisibleCardsCount() {
            if (window.innerWidth <= 768) return 1; // 1 column on mobile and portrait tablets
            if (window.innerWidth <= 992) return 2;
            return 3;
        }

        function getMaxIndex() {
            return cards.length - getVisibleCardsCount();
        }

        function updateCarousel() {
            const visibleCount = getVisibleCardsCount();
            const maxIndex = getMaxIndex();
            
            // Adjust current index if it exceeds max index due to resize
            if (currentIndex > maxIndex) {
                currentIndex = maxIndex;
            }

            if (cards.length > 0) {
                const cardWidth = cards[0].getBoundingClientRect().width;
                const gap = 30;
                const amountToMove = currentIndex * (cardWidth + gap);
                track.style.transform = `translateX(-${amountToMove}px)`;
            }

            // Update dots
            updateDots();
        }

        function createDots() {
            if (!dotsContainer) return;
            dotsContainer.innerHTML = '';
            const dotsCount = getMaxIndex() + 1;
            
            for (let i = 0; i < dotsCount; i++) {
                const dot = document.createElement('div');
                dot.classList.add('carousel-dot');
                if (i === 0) dot.classList.add('active');
                dot.addEventListener('click', () => {
                    currentIndex = i;
                    updateCarousel();
                });
                dotsContainer.appendChild(dot);
            }
        }

        function updateDots() {
            if (!dotsContainer) return;
            const dots = Array.from(dotsContainer.children);
            dots.forEach((dot, idx) => {
                if (idx === currentIndex) {
                    dot.classList.add('active');
                } else {
                    dot.classList.remove('active');
                }
            });
        }

        // Event Listeners
        nextBtn.addEventListener('click', () => {
            const maxIndex = getMaxIndex();
            if (currentIndex >= maxIndex) {
                currentIndex = 0; // Loop around to beginning
            } else {
                currentIndex++;
            }
            updateCarousel();
        });

        prevBtn.addEventListener('click', () => {
            const maxIndex = getMaxIndex();
            if (currentIndex <= 0) {
                currentIndex = maxIndex; // Loop around to end
            } else {
                currentIndex--;
            }
            updateCarousel();
        });

        // Initialize Carousel
        createDots();
        
        // Wait for images or layout to load fully for accurate widths
        window.addEventListener('load', updateCarousel);
        // Recalculate on window resize
        window.addEventListener('resize', () => {
            createDots();
            updateCarousel();
        });

        // Initial trigger
        setTimeout(updateCarousel, 100);

        // Swipe gestures support for mobile touch devices
        let startX = 0;
        let isSwiping = false;

        track.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            isSwiping = true;
        }, { passive: true });

        track.addEventListener('touchmove', (e) => {
            if (!isSwiping) return;
            const diffX = e.touches[0].clientX - startX;
            if (Math.abs(diffX) > 50) {
                if (diffX > 0) {
                    prevBtn.click();
                } else {
                    nextBtn.click();
                }
                isSwiping = false;
            }
        }, { passive: true });

        track.addEventListener('touchend', () => {
            isSwiping = false;
        });
    }

    // Instagram Feed Slider Logic
    const instaTrack = document.getElementById('insta-track');
    const instaPrevBtn = document.getElementById('insta-prev');
    const instaNextBtn = document.getElementById('insta-next');
    
    if (instaTrack && instaPrevBtn && instaNextBtn) {
        const cards = Array.from(instaTrack.children);
        let currentIndex = 0;

        function getVisibleCardsCount() {
            if (window.innerWidth <= 576) return 1;
            if (window.innerWidth <= 992) return 2;
            return 4; // 4 items visible on desktop
        }

        function getMaxIndex() {
            return Math.max(0, cards.length - getVisibleCardsCount());
        }

        function updateSlider() {
            const visibleCount = getVisibleCardsCount();
            const maxIndex = getMaxIndex();
            
            if (currentIndex > maxIndex) {
                currentIndex = maxIndex;
            }

            if (cards.length > 0) {
                const cardWidth = cards[0].getBoundingClientRect().width;
                const gap = 24;
                const amountToMove = currentIndex * (cardWidth + gap);
                instaTrack.style.transform = `translateX(-${amountToMove}px)`;
            }

            // Hide arrows if all cards are visible
            if (maxIndex === 0) {
                instaPrevBtn.style.display = 'none';
                instaNextBtn.style.display = 'none';
            } else {
                instaPrevBtn.style.display = 'flex';
                instaNextBtn.style.display = 'flex';
            }
        }

        instaNextBtn.addEventListener('click', () => {
            const maxIndex = getMaxIndex();
            if (currentIndex >= maxIndex) {
                currentIndex = 0;
            } else {
                currentIndex++;
            }
            updateSlider();
        });

        instaPrevBtn.addEventListener('click', () => {
            const maxIndex = getMaxIndex();
            if (currentIndex <= 0) {
                currentIndex = maxIndex;
            } else {
                currentIndex--;
            }
            updateSlider();
        });

        window.addEventListener('load', updateSlider);
        window.addEventListener('resize', updateSlider);
        setTimeout(updateSlider, 100);

        // Touch Swipe support for mobile devices
        let startX = 0;
        let isSwiping = false;

        instaTrack.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            isSwiping = true;
        }, { passive: true });

        instaTrack.addEventListener('touchmove', (e) => {
            if (!isSwiping) return;
            const diffX = e.touches[0].clientX - startX;
            if (Math.abs(diffX) > 50) {
                if (diffX > 0) {
                    instaPrevBtn.click();
                } else {
                    instaNextBtn.click();
                }
                isSwiping = false;
            }
        }, { passive: true });

        instaTrack.addEventListener('touchend', () => {
            isSwiping = false;
        });
    }
});

// Remove logo loading animation when page is fully loaded
(function() {
    const removeLoading = () => {
        document.querySelectorAll('.logo-emoji').forEach(emoji => {
            emoji.classList.remove('logo-loading');
        });
    };
    if (document.readyState === 'complete') {
        removeLoading();
    } else {
        window.addEventListener('load', removeLoading);
    }
})();
